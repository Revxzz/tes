const chalk = require("chalk");
const fs = require("fs");

global.usePairingCode = true
global.owner = "6285143569877"

global.idChannel = "120363401576774375@newsletter"
global.namaChannel = "~ Revxz Testimoni"
global.linkChannel = "https://whatsapp.com/channel/0029VbA1wgR4IBh8IIHBqo0Y"
global.gambar = "https://files.catbox.moe/mxivn5.jpg"

global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.loc = "1" // Isi id location
global.domain = "https://revxz.biz.id"
global.apikey = "ptla_0sIqDjVTExSW7WN5BO7Ot9B3fv7iYR6zp2g2F6ZWJXI" // Isi api ptla
global.capikey = "ptlc_7fQ2IzBGpi50bYl3WQQYST2IprS4ZmqG4toaj1OGe91" // Isi api ptlc

global.subdomain = {
  "vipserver.web.id": {
    "zone": "e305b750127749c9b80f41a9cf4a3a53",
    "apitoken": "miYhd-eMAiUmp9MniS6EsKFXnJ8D4Rofp9-GYHZw"
  },
  "mypanelstore.web.id": {
    "zone": "c61c442d70392500611499c5af816532",
    "apitoken": "gqg5B6_1UQhb72wg4zS1U7AGNbofMYRXT8zFiKZC"
  },
  "privatserver.my.id": {
    "zone": "699bb9eb65046a886399c91daacb1968",
    "apitoken": "KBkS9zIPdG0blhqtPMUjG8z8x8xumauCRuXvY_E1"
  },
  "serverku.biz.id": {
    "zone": "4e4feaba70b41ed78295d2dcc090dd3a",
    "apitoken": "b4YP7XhbliFuqgiXnz3gBvrmXfzgxuKQIkXEJjM7"
  },
  "skyzopedia.xyz": {
    "zone": "4252a8c37f07d26c533683405e22cd3e",
    "apitoken": "OgRcjkpZ0ESvWKHJTmpO7OuNgPSw0H8Et44MIu2Y"
  }
}


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.blue(">> Update File :"), chalk.black.bgWhite(`${__filename}`))
delete require.cache[file]
require(file)
})